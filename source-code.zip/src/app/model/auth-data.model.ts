export interface AuthData {
    preName?: string;
    name?: string;
    score?: number;
    email: string;
    password: string
}